@extends('adminlte::page')

@section('title', 'Dashboard Administrador')

@section('content_header')
    <h1>Dashboard Administración</h1>
@stop

@section('content')
    <p>Bienvenido al panel: mostraremos estadisticas de la página</p>
@stop