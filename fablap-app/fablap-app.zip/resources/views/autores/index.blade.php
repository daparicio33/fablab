@extends('adminlte::page')

@section('title', 'Dashboard Autores')

@section('content_header')
    <h1>Dashboard - Autores</h1>
@stop

@section('content')
    <p>Bienvenido a este hermoso panel de administración.</p>
@stop