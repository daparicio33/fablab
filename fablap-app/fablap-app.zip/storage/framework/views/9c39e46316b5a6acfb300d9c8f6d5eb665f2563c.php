

<?php $__env->startSection('title', 'Dashboard Autores'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard - Autores</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <p>Bienvenido a este hermoso panel de administración.</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dave\Desktop\fablab\fablap-app\resources\views/autores/index.blade.php ENDPATH**/ ?>