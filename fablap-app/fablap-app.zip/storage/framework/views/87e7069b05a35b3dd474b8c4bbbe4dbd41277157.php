
<?php $__env->startSection('cuerpo'); ?>

<!-- ======= Breadcrumbs ======= -->
<div class="breadcrumbs">
  <div class="page-header d-flex align-items-center" style="background-image: url('');">
    <div class="container position-relative">
      <div class="row d-flex justify-content-center">
        <div class="col-lg-8 text-center">
          <h2><?php echo e($proyecto->nombre); ?></h2>
          <p>Por: <?php echo e($proyecto->user->name); ?></p>
        </div>
      </div>
    </div>
  </div>
  <nav>
    <div class="container">
      <ol>
        <li><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
        <li>Proyecto</li>
      </ol>
    </div>
  </nav>
</div><!-- End Breadcrumbs -->

<!-- ======= Blog Details Section ======= -->
<section id="blog" class="blog">
  <div class="container" data-aos="fade-up">
    <div class="row g-5">
      <div class="col-lg-8">
        <article class="blog-details">
          <div class="post-img">
            <img src="<?php echo e(Storage::url($proyecto->url)); ?>" alt="" class="img-fluid">
          </div>
          <h2 class="title"><?php echo e($proyecto->nombre); ?></h2>
          <div class="meta-top">
            <ul>
              <li class="d-flex align-items-center">
                <i class="bi bi-person"></i> 
                <a href="blog-details.html"><?php echo e($proyecto->user->name); ?></a>
              </li>
              <li class="d-flex align-items-center">
                <i class="bi bi-clock"></i> 
                <a href="blog-details.html">
                  <time datetime="2020-01-01"><?php echo e(date('d-M-Y',strtotime($proyecto->fecha))); ?></time>
                </a>
              </li>
              <li class="d-flex align-items-center">
                <i class="bi bi-chat-dots"></i> 
                <a href="blog-details.html">
                  12 Comments
                </a>
              </li>
            </ul>
          </div><!-- End meta top -->

          <div class="content">
            <p style="text-align: justify">
              <?php echo e($proyecto->descripcion); ?>

            </p>
          </div>
        </article>
        <!-- End blog post -->
        <article class="blog-details">
          <h2 class="title">Entradas del Proyecto</h2>
          <div class="meta-top">
            <div class="accordion accordion-flush" id="accordionFlushExample">
              <?php $__currentLoopData = $proyecto->entradas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entrada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="accordion-item">
                  <h2 class="accordion-header" id="flush-headingOne<?php echo e($entrada->id); ?>">
                    <button class="accordion-button collapsed" 
                    type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse<?php echo e($entrada->id); ?>" 
                    aria-expanded="false" aria-controls="flush-collapse<?php echo e($entrada->id); ?>">
                      <?php echo e($entrada->titulo); ?>

                    </button>
                  </h2>
                  <div id="flush-collapse<?php echo e($entrada->id); ?>" class="accordion-collapse collapse" aria-labelledby="flush-heading<?php echo e($entrada->id); ?>" data-bs-parent="#accordionFlushExample">
                    <div class="accordion-body">
                    
                      <div class="row">
                        <p>
                          <?php echo e($entrada->descripcion); ?> <code><small><?php echo e(date('d-M-Y',strtotime($entrada->fecha))); ?></small></code>
                        </p>
                        <label for="" class="mb-5">
                          <i class="bi bi-images"></i> Imagenes
                        </label>
                        <?php $__currentLoopData = $entrada->medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($media->tipo == 'imagen'): ?>
                            <div class="col-sm-12 col-md-3 col-lg-3">
                              <figure class="figure">
                                <a data-zoomable="true" data-glightbox="description:<?php echo e($media->descripcion); ?>" href="<?php echo e(Storage::url($media->url)); ?>" class="glightbox" data-gallery="gallery<?php echo e($entrada->id); ?>">
                                  <img src="<?php echo e(Storage::url($media->url)); ?>" class="figure-img img-fluid rounded" alt="imagen no disponible">
                                </a>
                                <figcaption class="figure-caption"><?php echo e($media->descripcion); ?></figcaption>
                              </figure>
                            </div>
                          <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        <label for="">
                          <i class="bi bi-camera-reels"></i> Videos 
                        </label>
                        <?php $__currentLoopData = $entrada->medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($media->tipo == 'video'): ?>
                          <div class="col-sm-12 col-md-12 col-lg-12">
                            <section id="call-to-action" class="call-to-action">
                              <div class="container text-center" data-aos="zoom-out">
                                <a href="<?php echo e($media->url); ?>" class="glightbox play-btn"></a>
                                <p><?php echo e($media->descripcion); ?></p>
                              </div>
                            </section>
                          </div>
                          <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        <label for="">
                          <i class="bi bi-archive"></i> Archivos 
                        </label>
                          <div class="col-sm-12 col-md-12 col-lg-12">
                                <?php $__currentLoopData = $entrada->medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <?php if($media->tipo == 'archivo'): ?>
                                  <div class="card mt-3">
                                  <div class="card-body">
                                    <small><?php echo e($media->descripcion); ?></small>
                                  </div>
                                  <div class="card-footer text-muted">
                                    <a href="<?php echo e(Storage::url($media->url)); ?>">
                                      <small>
                                        <i class="bi bi-cloud-download"></i> descargar
                                      </small>
                                    </a>
                                  </div>
                                  </div>
                                  <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </div>
                        
                      </div>
                    </div>
                  </div>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </article>
      
        <!-- End post author -->

        

      </div>

      <div class="col-lg-4">

        <div class="sidebar">

          <div class="sidebar-item search-form">
            <h3 class="sidebar-title">Buscar</h3>
            <form action="" class="mt-3">
              <input type="text">
              <button type="submit"><i class="bi bi-search"></i></button>
            </form>
          </div><!-- End sidebar search formn-->

          

          <div class="sidebar-item recent-posts">
            <h3 class="sidebar-title">Entradas del Proyecto</h3>

            <div class="mt-3">
              <?php $__currentLoopData = $proyecto->entradas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entrada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="post-item" style="overflow: auto" >
                  <img src="<?php echo e(Storage::url('public/defaultLogo.png')); ?>" alt="">
                  <div>
                    <h4><a href="blog-details.html"><?php echo e($entrada->titulo); ?></a></h4>
                    <time datetime="2020-01-01"><?php echo e(date('d-M-Y',strtotime($entrada->fecha))); ?></time>
                  </div>
                </div>
              <!-- End recent post item-->
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

          </div><!-- End sidebar recent posts-->

          

        </div><!-- End Blog Sidebar -->

      </div>
    </div>

  </div>
</section><!-- End Blog Details Section -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dave\Desktop\fablab\fablap-app\resources\views/proyectos/show.blade.php ENDPATH**/ ?>