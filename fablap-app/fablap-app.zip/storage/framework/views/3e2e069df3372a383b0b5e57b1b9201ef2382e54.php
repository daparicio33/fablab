<div class="modal fade" id="multimedia-<?php echo e($entrada->id); ?>" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <?php echo Form::open(['route'=>['dashboard.medias.store'],'method'=>'post','enctype'=>'multipart/form-data']); ?>

    <div class="modal-dialog modal-dialog-centered modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title"><i class="far fa-file-video text-primary"></i> Agregar contenido Multimedia</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="row">
            <div class="col-sm-12 col-md-8">
              <div class="form-group">
                <div class="row mb-2">
                  <div class="col-sm-12 col-md-6">
                    <label for="">Tipo</label>
                    <select class="custom-select" id="tipo<?php echo e($entrada->id); ?>" name="tipo" onchange="cambiartipo(<?php echo e($entrada->id); ?>)" >
                        <option value="imagen">Imagen</option>
                        <option value="archivo">Archivo</option>
                        <option value="video">Video</option>
                    </select>
                  </div>
                </div>
                  <label for="">Recurso</label>
                  <input type="file" name="url" id="url<?php echo e($entrada->id); ?>" class="form-control" onchange="previewimage(event,'#imgpreview<?php echo e($entrada->id); ?>')"  required>
                  <label for="">Descripcion</label>
                  <?php echo Form::hidden('proyecto_id', $proyecto->id, [null]); ?>

                  <?php echo Form::textarea('descripcion', null, ['class'=>'form-control','required','rows'=>3]); ?>

                  <?php echo Form::hidden('entrada_id', $entrada->id, [null]); ?>

              </div>
            </div>
            <div class="col-sm-12 col-md-4">
              <img src="" id="imgpreview<?php echo e($entrada->id); ?>" width="90%" alt="imagen no disponible">
            </div>
          </div>

            
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">
                <i class="fas fa-backward"></i> Cancelar
            </button>
            <button type="submit" class="btn btn-danger">
                <i class="far fa-save"></i> Guardar
            </button>
        </div>
      </div>
    </div>
    <?php echo Form::close(); ?>

  </div><?php /**PATH C:\Users\Dave\Desktop\fablab\fablap-app\resources\views/dashboard/entradas/multimedia.blade.php ENDPATH**/ ?>