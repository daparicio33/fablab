

<?php echo $__env->make('adminlte::auth.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dave\Desktop\fablab\fablap-app\resources\views/auth/login.blade.php ENDPATH**/ ?>