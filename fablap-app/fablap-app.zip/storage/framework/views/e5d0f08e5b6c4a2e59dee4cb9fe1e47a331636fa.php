
<?php $__env->startSection('title', 'Dashboard | Entradas'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1 class="mb-2">Lista de Entradas del Proyecto</h1>
    <h6 class='h6 mb-3 text-danger'><?php echo e($proyecto->nombre); ?></h5>
    
    <form action="<?php echo e(asset('dashboard/entradas/create')); ?>" method="get">
        <?php echo Form::hidden('proyecto_id', $proyecto->id, [null]); ?>

        <button class="btn btn-success">
            <i class="fas fa-list-ol"></i>
            Nueva Entrada
        </button>
    </form>
    
    <?php if(session('info')): ?>
        <div class="alert alert-success mt-3" id='info'>
            <strong><?php echo e(session('info')); ?></strong>
        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger mt-3" id='error'>
            <strong><?php echo e(session('error')); ?></strong>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="table-responsive-sm">
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th scope="col">Titulo</th>
                    <th scope="col">Fecha</th>
                    <th scope="col">Descripcion</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $entradas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entrada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="font-weight-bold"><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($entrada->titulo); ?></td>
                        <td><?php echo e(date('d-m-Y',strtotime($proyecto->fecha))); ?></td>
                        <td><?php echo e($entrada->descripcion); ?></td>
                        <td style="width: 170px; text-align: center">
                            <a href="<?php echo e(route('dashboard.entradas.edit',$entrada->id)); ?>" title="Editar proyecto">
                                <button class="btn btn-info">
                                    <i class="far fa-edit"></i>
                                </button>
                            </a>
                            <a href="" data-target="#modal-delete-<?php echo e($entrada->id); ?>" data-toggle="modal"  class="btn btn-danger" title="Eliminar proyecto">
                                <i class="fas fa-trash-alt"></i>
                            </a>
                            <a href="" data-target="#multimedia-<?php echo e($entrada->id); ?>" data-toggle="modal" title="Agregar multimedia">
                                <button class="btn btn-success">
                                    <i class="fas fa-images"></i>
                                </button>
                            </a>
                        </td>
                        <?php echo $__env->make('dashboard.entradas.multimedia', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php echo $__env->make('dashboard.entradas.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </tr>
                    
                    <tr>
                        <td colspan="4">
                            Imagenes
                        </td>
                    </tr>
                    <tr>
                        <td colspan="4">
                            <div class="row">
                                <?php $__currentLoopData = $entrada->medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($media->tipo == 'imagen'): ?>
                                <div class="col-sm-12 col-md-6 col-lg-3">
                                    <div class="card">
                                        <img src="<?php echo e(Storage::url($media->url)); ?>" class="card-img-top" alt="imagen no disponible">
                                        <div class="card-body">
                                        <h6 class="card-title"><?php echo e($media->tipo); ?></h6>
                                        <p class="card-text">
                                            <?php echo e($media->descripcion); ?>

                                        </p>
                                        <a href="" data-target="#modal-delete-<?php echo e($media->id); ?>" data-toggle="modal" class="btn btn-danger" title="eliminar">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                        </div>
                                    </div>
                                </div>
                                <?php echo $__env->make('dashboard.medias.mdelete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </td>
                    </tr>
                    
                    
                    <tr>
                        <td colspan="4">
                            Videos
                        </td>
                    </tr>
                    <tr>
                        <td colspan="4">
                            <div class="row">
                                <?php $__currentLoopData = $entrada->medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($media->tipo == 'video'): ?>
                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                        <div class="card">
                                            <div class="ratio ratio-16x9">
                                                <iframe src="<?php echo e($media->url); ?>" title="YouTube video" style="width: 100%" allowfullscreen></iframe>
                                            </div>
                                            <div class="card-body">
                                            <h6 class="card-title"><?php echo e($media->tipo); ?></h6>
                                            <p class="card-text">
                                                <?php echo e($media->descripcion); ?>

                                            </p>
                                            <a href="" data-target="#modal-delete-<?php echo e($media->id); ?>" data-toggle="modal" class="btn btn-danger" title="eliminar">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                            </div>
                                        </div>
                                    </div>
                                    <?php echo $__env->make('dashboard.medias.mdelete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </td>
                    </tr>
                    
                    
                    <tr>
                        <td colspan="4">
                            Archivos
                        </td>
                    </tr>
                    <tr>
                        <td colspan="4">
                            <div class="row">
                                <?php $__currentLoopData = $entrada->medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($media->tipo == 'archivo'): ?>
                                <div class="col-sm-12 col-md-6 col-lg-3">
                                    <div class="card">
                                        <img src="<?php echo e(Storage::url('public/defaultFile.png')); ?>" class="card-img-top" alt="imagen no disponible">
                                        <div class="card-body">
                                        <h5 class="card-title"><?php echo e($media->tipo); ?></h5>
                                        <p class="card-text">
                                            <?php echo e($media->descripcion); ?>

                                            <a href="<?php echo e(Storage::url($media->url)); ?>">descargar aca</a>
                                        </p>
                                        <a href="" data-target="#mdelete-<?php echo e($media->id); ?>" data-toggle="modal"  class="btn btn-danger" title="eliminar">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                        </div>
                                    </div>
                                </div>
                                <?php echo $__env->make('dashboard.medias.mdelete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </td>
                    </tr>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dave\Desktop\fablab\fablap-app\resources\views/dashboard/entradas/index.blade.php ENDPATH**/ ?>