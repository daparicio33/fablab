
<?php $__env->startSection('cuerpo'); ?>
<!-- ======= Breadcrumbs ======= -->
<div class="breadcrumbs">
  <div class="page-header d-flex align-items-center" style="background-image: url('');">
    <div class="container position-relative">
      <div class="row d-flex justify-content-center">
        <div class="col-lg-6 text-center">
          <h2>Proyectos</h2>
          <p>nuestra lista de proyectos FAB LAB</p>
        </div>
      </div>
    </div>
  </div>
  <nav>
    <div class="container">
      <ol>
        <li><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
        <li>Proyectos</li>
      </ol>
    </div>
  </nav>
</div><!-- End Breadcrumbs -->

<!-- ======= Blog Section ======= -->
<section id="blog" class="blog">
  <div class="container" data-aos="fade-up">
    
    <div class="row gy-4 posts-list">
      <?php $__currentLoopData = $proyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-xl-4 col-md-6">
        <article>
          <div class="post-img">
            <img src="<?php echo e(Storage::url($proyecto->url)); ?>" alt="" class="img-fluid">
          </div>
          <p class="post-category">Politics</p>
          <h2 class="title">
            <a href="<?php echo e(route('home.proyectos.show', $proyecto->id)); ?>"><?php echo e($proyecto->nombre); ?></a>
          </h2>
          <div class="d-flex align-items-center">
            <img src="<?php echo e(Storage::url($proyecto->user->foto)); ?>" alt="" class="img-fluid post-author-img flex-shrink-0">
            <div class="post-meta">
              <p class="post-author-list"><?php echo e($proyecto->user->name); ?></p>
              <p class="post-date">
                <time datetime="2022-01-01"><?php echo e(date('d-M-Y',strtotime($proyecto->fecha))); ?></time>
              </p>
            </div>
          </div>
        </article>
      
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- End post list item -->
    
  </div>
  <!-- End blog posts list -->
  <div class="blog-pagination">
      <ul class="justify-content-center">
        <li><a href="#">1</a></li>
        <li class="active"><a href="#">2</a></li>
        <li><a href="#">3</a></li>
      </ul>
  </div><!-- End blog pagination -->  
</section><!-- End Blog Section -->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dave\Desktop\fablab\fablap-app\resources\views/proyectos/index.blade.php ENDPATH**/ ?>