
<?php $__env->startSection('title', 'Administrador | Nuevo'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Nuevo Usuario</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo Form::model($user, ['route'=>['dashboard.administrators.update',$user->id],'method'=>'PUT']); ?>

    <div class="row">
        <div class="col-sm-12 col-sm-7 col-lg-7">
            <div class="form-group">
                <label for="">
                   <i class="fas fa-file-signature"></i> Nombre
                </label>
                <?php echo Form::text('name', null, ['class'=>'form-control','required' ]); ?>

                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="alert alert-danger d-block p-1 mt-1" role="alert">
                        <i class="fas fa-exclamation-triangle"> </i> <?php echo e($message); ?>

                    </small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <label class="mt-2" for="">
                   <i class="fas fa-envelope"></i> Email
                </label>
                <?php echo Form::email('email', null, ['class'=>'form-control','required']); ?>

                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="alert alert-danger d-block p-1 mt-1" role="alert">
                        <i class="fas fa-exclamation-triangle"> </i> <?php echo e($message); ?>

                    </small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <label class="mt-2" for="">
                    <i class="fas fa-key"></i> Contraseña
                </label>
                <div class="input-group">
                    <input type="password" class="form-control" placeholder="" name="password" id="password">
                    <div class="input-group-prepend">
                      <button class="btn btn-outline-secondary" onclick="mostrarContrasena()" type="button" id="btnpassword">
                        <i class="far fa-eye" id='iconpassword'></i>
                    </button>
                    </div>
                </div>
                
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="alert alert-danger d-block p-1 mt-1" role="alert">
                        <i class="fas fa-exclamation-triangle"> </i> <?php echo e($message); ?>

                    </small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <label class="mt-2" for="">
                    <i class="fas fa-keyboard"></i>
                    Tipo
                </label>
                <?php echo Form::select('tipo', $tipos, null, ['class'=>'form-control']); ?>

                <label class="mt-2" for="">Sexo</label>
                <?php $__currentLoopData = $sexos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sexo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check">
                        <input class="form-check-input" value="<?php echo e($sexo); ?>" type="radio" name="sexo" id="sexo" <?php if($user->sexo == $sexo): ?> checked <?php endif; ?>>
                        <label class="form-check-label" for="sexo">
                        <?php echo e($sexo); ?>

                        </label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <button type="submit" class="btn btn-primary mt-3" id="btn">
                   <i class="fas fa-save"></i> Guardar
                </button>
            </div>
        </div>
    </div>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dave\Desktop\fablab\fablap-app\resources\views/dashboard/administrator/edit.blade.php ENDPATH**/ ?>