

<?php $__env->startSection('title', 'Administrador -> Autores'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="mb-2">Lista de Autores del Sistema</h1>
    <a href="<?php echo e(route('administradores.autores.create')); ?>">
        <button class="btn btn-success">
            <i class="fas fa-user"></i>
            Nuevo Autor
        </button>
    </a>
    <?php if(session('info')): ?>
        <div class="alert alert-success mt-3" id='info'>
            <strong><?php echo e(session('info')); ?></strong>
        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger mt-3" id='error'>
            <strong><?php echo e(session('error')); ?></strong>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="table-responsive-sm">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Nombre</th>
                    <th scope="col">Email</th>
                    <th scope="col">Proyecto</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $autores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autore): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($autore->user->name); ?></td>
                        <td><?php echo e($autore->user->email); ?></td>
                        <td><?php echo e($autore->proyecto->nombre); ?></td>
                        <td style="width: 170px; text-align: center">
                            <a href="<?php echo e(route('administradores.autores.edit',$autore->id)); ?>">
                                <button class="btn btn-info">
                                    <i class="far fa-edit"></i> Editar
                                </button>
                            </a>
                            <a data-target="#modal-delete-<?php echo e($autore->id); ?>" data-toggle="modal" href="" class="btn btn-danger" title="eliminar matricula">
                                <i class="fas fa-trash-alt"></i>
                            </a>
                        </td>
                        
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script> 
        $(document).ready(function(){
        setTimeout(() => {
            $("#info").hide();
        }, 12000);
        });
        $(document).ready(function(){
            setTimeout(() => {
            $("#error").hide();
        }, 12000);
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dave\Desktop\fablab\fablap-app\resources\views/administradores/autores/index.blade.php ENDPATH**/ ?>