
<?php $__env->startSection('titulo','Inicio ..'); ?>
<?php $__env->startSection('slider'); ?>
  <?php echo $__env->make('layouts.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('cuerpo'); ?>
<!-- ======= Recent Blog Posts Section ======= -->
<section id="recent-posts" class="recent-posts sections-bg">
  <div class="container" data-aos="fade-up">

    <div class="section-header">
      <h2>Proyectos Fab IDEX Perú Japón</h2>
      <p>da un vistazo a nuestos proyectos mas recientes ...</p>
    </div>

    <div class="row gy-4">
      
      <?php $__currentLoopData = $proyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- Start post list item -->
        <div class="col-xl-4 col-md-6">
          <article>
            <div class="post-img">            
              <img src="<?php echo e(Storage::url($proyecto->url)); ?>" alt="" class="img-fluid">
            </div>
            <p class="post-category"><?php echo e(end($proyecto->entradas)); ?></p>
            <h2 class="title">
              <a href="<?php echo e(route('home.proyectos.show',$proyecto->id)); ?>"><?php echo e($proyecto->nombre); ?></a>
            </h2>
            <div class="d-flex align-items-center">
              <img src="<?php echo e(Storage::url($proyecto->user->foto)); ?>" alt="" class="img-fluid post-author-img flex-shrink-0">
              <div class="post-meta">
                <p class="post-author"><?php echo e($proyecto->user->name); ?></p>
                <p class="post-date">
                  <time><?php echo e(date('d-M-Y',strtotime($proyecto->fecha))); ?></time>
                </p>
              </div>
            </div>
          </article>
        </div>
        <!-- End post list item -->
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <!-- End recent posts list -->
  </div>
</section>
<!-- End Recent Blog Posts Section -->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dave\Desktop\fablab\fablap-app\resources\views/index.blade.php ENDPATH**/ ?>