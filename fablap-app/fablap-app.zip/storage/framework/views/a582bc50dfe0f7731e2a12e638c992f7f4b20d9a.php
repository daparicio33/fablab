

<?php $__env->startSection('title', 'Administrador | Proyectos'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="mb-2">Lista de Proyectos del Sistema</h1>
    <a href="<?php echo e(route('administradores.proyectos.create')); ?>">
        <button class="btn btn-success">
            <i class="fab fa-product-hunt"></i>
            Nuevo Proyecto
        </button>
    </a>
    <?php if(session('info')): ?>
        <div class="alert alert-success mt-3" id='info'>
            <strong><?php echo e(session('info')); ?></strong>
        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger mt-3" id='error'>
            <strong><?php echo e(session('error')); ?></strong>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="table-responsive-sm">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Nombre</th>
                    <th scope="col">Fecha</th>
                    <th scope="col">Opciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $proyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($proyecto->nombre); ?></td>
                        <td><?php echo e(date('d-m-Y',strtotime($proyecto->fecha))); ?></td>
                        <td style="width: 170px; text-align: center">
                            <a href="<?php echo e(route('administradores.proyectos.edit',$proyecto->id)); ?>">
                                <button class="btn btn-info">
                                    <i class="far fa-edit"></i> Editar
                                </button>
                            </a>
                            <a data-target="#modal-delete-<?php echo e($proyecto->id); ?>" data-toggle="modal" href="" class="btn btn-danger" title="eliminar matricula">
                                <i class="fas fa-trash-alt"></i>
                            </a>
                        </td>
                        <?php echo $__env->make('administradores.proyectos.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dave\Desktop\fablab\fablap-app\resources\views/administradores/proyectos/index.blade.php ENDPATH**/ ?>