

<?php $__env->startSection('title', 'Dashboard Administrador'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard Administración</h1>
    <a href="<?php echo e(route('dashboard.administrators.create')); ?>">
        <button class="btn btn-success">
            <i class="fas fa-user-friends"></i> Nuevo Usuario
        </button>
    </a>
    <?php echo $__env->make('layouts.info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <p>Bienvenido al panel: mostranto usuarios del sistema</p>
    <div class="table-responsive-sm">
        <table class="table">
            <thead>
                <tr>
                    <td>Foto</td>
                    <td>Nombre</td>
                    <td>Correo</td>
                    <td>Tipo</td>
                    <td>Sexo</td>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <img class="rounded mx-auto d-block" style="width: 70px" src="<?php echo e(Storage::url($user->foto)); ?>" alt="">
                    </td>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->tipo); ?></td>
                    <td><?php echo e($user->sexo); ?></td>
                    <td>
                        <a href="<?php echo e(route('dashboard.administrators.edit',$user->id)); ?>" title="Editar usuario" class="btn btn-primary">
                            <i class="fas fa-edit"></i>
                        </a>
                        <a href="" data-target="#modal-delete-<?php echo e($user->id); ?>" data-toggle="modal" class="btn btn-danger">
                            <i class="fas fa-trash"></i>
                        </a>
                    </td>
                </tr>
                <?php echo $__env->make('dashboard.administrator.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dave\Desktop\fablab\fablap-app\resources\views/dashboard/administrator/index.blade.php ENDPATH**/ ?>