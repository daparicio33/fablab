<div class="sidebar-item search-form">
    <h3 class="sidebar-title">Buscar</h3>
    <form action="" class="mt-3">
      <input type="text">
      <button type="submit"><i class="bi bi-search"></i></button>
    </form>
</div>